
// 1)
// input: 4 (minimum 4, maksimal 9)
//  *******
//   *   *
//    * *
//     *
// input: 6
// ***********
//  *       *
//   *     *
//    *   *
//     * *
//      *
// segitiga ke kanan
function triangleStar (num) {
    var result = '';
    // baris pertama
    for (var i = 0; i < num; i++) {
        
        for(var j = 0; j < i; j++) {
            result += ' ';

        }
        result += '*';

        
        result += '\n';
    }
    for (var i = num; i > 0; i--) {
        
        for(var j = i; j > 0; j--) {
            result += ' ';

        }
        result += '*';

        
        result += '\n';
    }
    return result;
}
// segitiga ke kiri
// function triangleStar (num) {
//     var result = '';
//     for (var i = num; i > 0; i--) {
        
//         for(var j = i; j > 0; j--) {
//             result += ' ';

//         }
//         result += '*';

        
//         result += '\n';
//     }
//     return result;
// }
console.log(triangleStar(4));